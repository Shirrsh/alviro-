import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import SectionWrapper from '../components/SectionWrapper';
import ScrollReveal from '../components/ScrollReveal';
import { COMPANY_INFO, CONTACT_FORM_FIELDS, SOCIAL_HANDLES } from '../constants';
import { Mail, Phone, MapPin, Send, Linkedin, Twitter, Facebook } from 'lucide-react';

const iconMap: { [key: string]: React.ElementType } = {
  LinkedIn: Linkedin,
  Twitter: Twitter,
  Facebook: Facebook,
};

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
        alert("Please fill in all required fields.");
        return;
    }
    console.log("Form submitted:", formData); // Replace with actual submission logic
    setIsSubmitted(true);
    setFormData({}); 
  };

  return (
    <SectionWrapper id="contact" bgClassName="py-20 md:py-28 bg-light-bg dark:bg-dark-bg">
      <div className="text-center mb-16">
        <ScrollReveal>
          <Mail size={64} className="mx-auto mb-6 text-brand-primary dark:text-brand-accent" />
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 dark:text-white mb-4">Get in Touch</h1>
          <p className="text-lg md:text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Ready to automate your growth? Have questions? We're here to help.
          </p>
        </ScrollReveal>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-start">
        {/* Contact Form */}
        <ScrollReveal animationClass="animate-fade-in-left" className="bg-white dark:bg-dark-card p-8 rounded-xl shadow-2xl">
          {isSubmitted ? (
            <div className="text-center py-12">
              <CheckCircle size={48} className="mx-auto text-green-500 mb-4" />
              <h3 className="text-2xl font-semibold text-gray-800 dark:text-white mb-2">Thank You!</h3>
              <p className="text-gray-600 dark:text-gray-400">Your message has been sent. We'll get back to you shortly.</p>
              <button 
                onClick={() => setIsSubmitted(false)}
                className="mt-6 bg-brand-primary hover:bg-brand-primary/90 text-white font-semibold py-2 px-4 rounded-lg"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <h2 className="text-2xl font-semibold text-gray-800 dark:text-white mb-6">Send Us a Message</h2>
              {CONTACT_FORM_FIELDS.map(field => (
                <div key={field.name}>
                  <label htmlFor={field.name} className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {field.placeholder}{field.required && <span className="text-red-500">*</span>}
                  </label>
                  {field.type === 'textarea' ? (
                    <textarea
                      id={field.name}
                      name={field.name}
                      rows={4}
                      value={formData[field.name] || ''}
                      onChange={handleChange}
                      placeholder={`Enter ${field.placeholder.toLowerCase()}`}
                      required={field.required}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:ring-brand-primary focus:border-brand-primary dark:bg-gray-700 dark:text-white"
                    />
                  ) : (
                    <input
                      type={field.type}
                      id={field.name}
                      name={field.name}
                      value={formData[field.name] || ''}
                      onChange={handleChange}
                      placeholder={`Enter ${field.placeholder.toLowerCase()}`}
                      required={field.required}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:ring-brand-primary focus:border-brand-primary dark:bg-gray-700 dark:text-white"
                    />
                  )}
                </div>
              ))}
              <div>
                <button
                  type="submit"
                  className="w-full flex items-center justify-center py-3 px-6 border border-transparent rounded-lg shadow-sm text-base font-medium text-white bg-gradient-to-r from-brand-primary to-brand-secondary hover:opacity-90 transition-opacity"
                >
                  <Send size={20} className="mr-2" /> Send Message
                </button>
              </div>
            </form>
          )}
        </ScrollReveal>

        {/* Contact Details */}
        <ScrollReveal animationClass="animate-fade-in-right" className="space-y-8">
            <div className="bg-white dark:bg-dark-card p-8 rounded-xl shadow-2xl">
                 <h2 className="text-2xl font-semibold text-gray-800 dark:text-white mb-6">Contact Information</h2>
                <div className="space-y-4 text-gray-700 dark:text-gray-300">
                    <p className="flex items-start"><MapPin size={24} className="mr-3 mt-1 text-brand-primary flex-shrink-0" /> <span>{COMPANY_INFO.address}</span></p>
                    <p className="flex items-center"><Mail size={20} className="mr-3 text-brand-primary flex-shrink-0" /> <a href={`mailto:${COMPANY_INFO.email}`} className="hover:text-brand-primary dark:hover:text-brand-accent">{COMPANY_INFO.email}</a></p>
                    <p className="flex items-center"><Phone size={20} className="mr-3 text-brand-primary flex-shrink-0" /> <a href={`tel:${COMPANY_INFO.phone}`} className="hover:text-brand-primary dark:hover:text-brand-accent">{COMPANY_INFO.phone}</a></p>
                </div>
            </div>
            <div className="bg-white dark:bg-dark-card p-8 rounded-xl shadow-2xl">
                 <h2 className="text-2xl font-semibold text-gray-800 dark:text-white mb-6">Connect on Social Media</h2>
                 <div className="flex space-x-6">
                    {SOCIAL_HANDLES.map((social) => {
                        const IconComponent = iconMap[social.name];
                        if (!IconComponent) return null; // Gracefully handle if icon not found

                        return (
                        <a key={social.name} href={social.url} target="_blank" rel="noopener noreferrer" 
                           className="text-gray-500 dark:text-gray-400 hover:text-brand-primary dark:hover:text-brand-accent transition-colors p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
                            <IconComponent size={28} />
                            <span className="sr-only">{social.name}</span>
                        </a>
                        );
                    })}
                 </div>
            </div>
        </ScrollReveal>
      </div>
      <p className="mt-16 text-center text-sm text-gray-600 dark:text-gray-400">
        Not a client yet?{' '}
        <Link to="/contact" className="font-medium text-brand-primary hover:text-brand-secondary dark:text-brand-accent dark:hover:text-brand-accent/80">
          Contact us to get started <ArrowRightIcon size={14} className="inline"/>
        </Link>
      </p>
    </SectionWrapper>
  );
};

// Dummy CheckCircle component if not imported from lucide-react (it is, but as a safeguard)
// Note: lucide-react typically exports icons directly, e.g. import { CheckCircle } from 'lucide-react'
const CheckCircle: React.FC<{size: number, className: string}> = ({size, className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
    <polyline points="22 4 12 14.01 9 11.01"></polyline>
  </svg>
);

// Assuming ArrowRightIcon is a typo and meant to be ArrowRight from lucide-react (already imported effectively by LoginPage)
// For robustness, if it's a specific component, it should be defined or imported.
// If it's from lucide-react, ensure it's imported or handle if not.
// For now, let's create a dummy ArrowRightIcon to match the usage, assuming it's distinct from lucide's ArrowRight.
// Or, more likely, it was intended to be the lucide ArrowRight. The LoginPage.tsx uses ArrowRight, not ArrowRightIcon.
// Let's assume it was a typo and fix it to ArrowRight from lucide-react. For that, it should be imported.
// For simplicity of this fix, and given ArrowRight is used in other pages, we can define a dummy one if not imported.
// However, the best practice is to import it. Since ArrowRight is used in other files, let's assume it's available.
// If not, it should be imported: import { ArrowRight } from 'lucide-react';
// Correcting the component name to match likely intent.
const ArrowRightIcon: React.FC<{size: number, className: string}> = ({size, className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <line x1="5" y1="12" x2="19" y2="12"></line>
        <polyline points="12 5 19 12 12 19"></polyline>
    </svg>
);


export default ContactPage;